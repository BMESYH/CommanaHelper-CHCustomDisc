추가하기 위해 수정해야 할 파일 목록:
assets/minecraft/sounds.json
assets/minecraft/models/item/music_disc_11.json

추가해야 할 파일
assets/minecraft/models/item/customdisc/에 .json 파일
assets/minecraft/sounds/customdisc/에 .ogg음악파일
assets/minecraft/textures/customdisc/에 .png 파일(선택)
